/******************************************************************************
Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#import <Foundation/Foundation.h>

int main (int argc, const char * argv[])
{
        //Declaring Variables
        float numDrinks, input;

        NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
        NSLog (@"Enter the amount of caffeine in milligrams");
        scanf("%f", &input);
        
        //Calculations
        numDrinks = (float) 10000 / input;
        
        numDrinks = ceil(numDrinks);
        
        NSLog (@"Number of drinks that will kill you %.0f", numDrinks);
        [pool drain];
        return 0;
}
