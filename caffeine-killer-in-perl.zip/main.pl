=begin

Caffeine Killer in Perl

Lines 16-19
https://www.go4expert.com/articles/ceil-floor-round-perl-t19166/

=end
=cut

print "Enter the amount of caffeine in milligrams ";
my $input = <STDIN>;

#Calculations
$numDrinks = 10000 / $input;

#Ceil $numDrinks
$ceilDrinks = sprintf("%.0f",$numDrinks)

#Display Deadly Results
print "Number of drinks that will kill you! $ceilDrinks";

