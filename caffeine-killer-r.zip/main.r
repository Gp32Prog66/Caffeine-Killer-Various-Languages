

input <- ""
numDrinks <- ""

"Enter the amount of caffeine in milligrams"
input = scan(what = double())

#Calculations
numDrinks = 10000 / input

ceiling(numDrinks)

print("Number of drinks that will kill you "numDrinks)