#include <iostream>
#include <math.h
#include <string>
using std::cout;
using std::endl;
using std::cin;
using std::string;

int main()
{
 string loop;
 do{
 
  //Variable
    double numDrinks;
    double input;

    cout << "Enter the amount of caffeine millilgrams" << endl;
   cin >> input;

    //Calculations
    numDrinks = 10000 / input;

    numDrinks = ceil(numDrinks);

    //Display Result

    cout << "Number of drinks that will kill you " << numDrinks << endl



}while(loop == "yes");
    return 0;
}
