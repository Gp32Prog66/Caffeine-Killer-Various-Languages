#include <math.h>
#include <stdio.h>

int main()
{
    //Variables
    float input;
    float numDrinks;
    
    printf("Enter the amount of caffeine in milligrams ");
    scanf("%f", &input);
    
    //Calculations
    numDrinks = (float) 10000 / input;
    
    numDrinks = ceil(numDrinks);
    
    
    //Display Result
    printf("Number of drinks that will kill you %.0f", numDrinks);
}