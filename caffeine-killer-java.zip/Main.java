import java.util.Scanner;


public class Main
{
	public static void main(String[] args) {
		//Declare Variables
        double numDrinks, input;
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Enter the amount of caffeine in milligrams");
        input = keyboard.nextDouble();
        
        //Calculations
        numDrinks = 10000/input;
        
        numDrinks = Math.ceil(numDrinks);
        
        //Display Results
        
        System.out.println("Number of drinks that will kill you " + numDrinks);
	}
}
