
print("Enter the amount of caffeine in milligrams")
let input = readLine()

//Calculations
let numDrinks = 100


print("Hello World")