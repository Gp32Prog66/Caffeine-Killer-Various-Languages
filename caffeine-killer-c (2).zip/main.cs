/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;


class HelloWorld {
  static void Main() {
      
      //Declare Variables
      double input, numDrinks;
      
    Console.WriteLine("Enter the amount of caffeine in milligrams");
    input = Convert.ToDouble(Console.ReadLine());
    
    //Calculations
    numDrinks = 10000 / input;
    
    numDrinks = Math.Ceiling(numDrinks);
    
    Console.WriteLine("Number of drinks that will kill you {0} ", numDrinks);
  }
}